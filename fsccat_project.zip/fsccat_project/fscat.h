/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   fscat.h
 * Author: student
 *
 * Created on September 15, 2023, 6:34 PM
 */

#ifndef FSCAT_H
#define FSCAT_H

#ifdef __cplusplus
extern "C" {
#endif


    void cpro() ;

#ifdef __cplusplus
}
#endif

#endif /* FSCAT_H */

