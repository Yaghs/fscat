#include "fscat.h"
#include <stdio.h>
#include <stdlib.h>
void cpro() {
    ///usr/include/stdio.h:258:44: note: expected ‘const char * restrict’ but argument is of type ‘char’  
    //the above is why I put const char instead of char 
    const char *filename = ("txt1.txt");
    
    FILE *fp = fopen(filename, "r");//reads file
    
    //code snippet used from the instructions in the HW 
    //checks to makesure that file pointer is null and if so gives an error 
    if (fp == NULL) {
        fprintf(stderr, "fscat: cannot open file %s\n", filename);
        exit(1);
    }
    // code from the tutorial video 
    char ch;
    while ((ch = fgetc(fp)) != EOF) {
        putchar(ch);
    }

    fclose(fp);
}

